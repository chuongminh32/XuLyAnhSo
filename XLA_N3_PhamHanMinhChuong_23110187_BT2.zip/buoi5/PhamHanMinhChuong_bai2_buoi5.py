import cv2
import numpy as np
import matplotlib.pyplot as plt

image_path = "G:/hcmute/semeter1-term2-2526/XLAS/code/buoi5/img1.jpg"
img = cv2.imread(image_path)
if img is None:
    exit("Không tìm thấy ảnh!")


#  Tạo nhiễu Muối tiêu
def add_salt_and_pepper_noise(image, noise_ratio=0.9):
    noisy_image = image.copy()
    h, w, c = noisy_image.shape
    noisy_pixels = int(h * w * noise_ratio)

    for _ in range(noisy_pixels):
        row, col = np.random.randint(0, h), np.random.randint(0, w)
        if np.random.rand() < 0.5:
            noisy_image[row, col] = [0, 0, 0]
        else:
            noisy_image[row, col] = [255, 255, 255]

    return noisy_image


noisy_img = add_salt_and_pepper_noise(img)

# Khử nhiễu
avg_result = cv2.blur(noisy_img, (5, 5))

median_result = cv2.medianBlur(noisy_img, 5)

plt.figure(figsize=(12, 5))
titles = ["Ảnh nhiễu Muối Tiêu", "Average Filter", "Median Filter"]
images = [noisy_img, avg_result, median_result]

for i in range(3):
    plt.subplot(1, 3, i + 1)
    plt.imshow(cv2.cvtColor(images[i], cv2.COLOR_BGR2RGB))
    plt.title(titles[i])
    plt.axis("off")

plt.show()
